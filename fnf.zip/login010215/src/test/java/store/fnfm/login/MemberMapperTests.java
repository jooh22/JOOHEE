package store.fnfm.login;

import static org.junit.Assert.*;

import org.junit.Test;

public class MemberMapperTests {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
